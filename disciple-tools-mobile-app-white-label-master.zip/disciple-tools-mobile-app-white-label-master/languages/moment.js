import moment from 'moment';
// Imports by supported languages
// English language set by default
require('moment/locale/ar');
require('moment/locale/bn');
require('moment/locale/es');
require('moment/locale/fa');
require('moment/locale/fr');
require('moment/locale/id');
require('moment/locale/nl');
require('moment/locale/pt');
require('moment/locale/ru');
require('moment/locale/sr');
require('moment/locale/sl');
require('moment/locale/hr');
require('moment/locale/sw');
require('moment/locale/tr');
require('moment/locale/zh-cn');
require('moment/locale/zh-tw');

export default moment;
