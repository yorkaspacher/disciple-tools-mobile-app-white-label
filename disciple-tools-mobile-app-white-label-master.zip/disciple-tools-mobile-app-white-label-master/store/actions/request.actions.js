/*
 * Action Types
 */
export const REQUEST = 'REQUEST';
export const RESPONSE = 'RESPONSE';
